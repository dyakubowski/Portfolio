# Portfolio
My practical tasks, mini-projects for future resume as Python Developer
